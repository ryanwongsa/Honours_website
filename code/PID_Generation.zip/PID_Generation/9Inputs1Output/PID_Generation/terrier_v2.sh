#!/bin/bash

./pid_gen Simulation\ Data/OldData.txt 2 3 100000 > Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 4 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 5 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 6 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 7 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 8 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 9 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 10 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 11 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 12 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 13 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 14 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 15 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 16 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 17 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 18 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 19 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 20 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 21 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 22 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 23 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 24 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 25 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 26 100000 >> Terrier_v2.txt

./pid_gen Simulation\ Data/OldData.txt 2 27 100000 >> Terrier_v2.txt
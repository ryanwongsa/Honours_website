#!/bin/bash

./pid_gen Simulation\ Data/NewDataLimited.txt 1 1 10000 > 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 1 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 1 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 2 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 2 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 2 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 3 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 3 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 3 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 4 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 4 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 4 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 5 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 5 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 5 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 6 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 6 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 6 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 7 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 7 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 7 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 8 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 8 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 8 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 1 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 2 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 3 10000 >> 9Inputs1Output_FINAL.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 4 10000 >> 9Inputs1Output_FINAL.txt


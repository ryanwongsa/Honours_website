#include "RunProgram.h"


	int main(int argc, char const *argv[])
	{
	 	std::srand ( unsigned ( std::time(0) ) );

		DataRetrieval dr(argv[1]);
	 	particles = dr.getParticles();
	
	 	std::random_shuffle ( particles.begin(), particles.end() );
	 	

	 	numHiddenLayers =atoi(argv[2]);
		numHiddenNodes = atoi(argv[3]);

		int generations = atoi(argv[4]);

		double trainPercent =0.8;

		cout << "==========================================================================================" << endl;
		cout << "Starting Neural Network" << endl;
		cout << "Number of Inputs: " << numInputs << endl;
		cout << "Number of Hidden Layers: " << numHiddenLayers << endl;
		cout << "Number of Hidden Nodes: " << numHiddenNodes << endl;
		cout << "Number of Outputs: " << numOutputs << endl; 
		cout << "Number of Generations: " << generations << endl;
		cout << "-------------------------------------------------------------------------------------------" << endl;


		int numTrainedParticles = particles.size()*trainPercent;
		cout << "Number of Trained Particles: " << numTrainedParticles  << endl;


		NeuronLayers neuronLayers(numInputs, numHiddenLayers, numHiddenNodes, numOutputs);


		for(int i=0;i<generations;i++)
		{
		//	std::random_shuffle ( particles.begin(), particles.begin()+numTrainedParticles );

			clog << "Generation No: "<< i<< " out of " << generations;
			for(int u=0;u<numTrainedParticles;u++) 
			{
				ParticleInformation particle = particles[u];

				fillInputs(particle, neuronLayers);
				fillTargets(particle, neuronLayers);

				neuronLayers.forwardPass();
				neuronLayers.backwardPass();
			}
			float error = fillNeuralNetworkPIDs(neuronLayers, 0, numTrainedParticles);
			float efficiency = makeNeuralNetworkHistogram(0,numTrainedParticles, false);	

			clog << "\t"<< efficiency << " " << error << endl;
		//	clog << endl;

		}

		//Trained Results
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "Trained Results" << endl;
		float error = fillNeuralNetworkPIDs(neuronLayers, 0, numTrainedParticles);

		float efficiency = makeNeuralNetworkHistogram( 0,numTrainedParticles, true);

		cout << "Error: " << error << endl; 
		cout << "Pion Efficiency: " << efficiency << endl; 

		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;

		//Untrained Results
		cout << "Untrained Results" << endl;
		error = fillNeuralNetworkPIDs(neuronLayers, numTrainedParticles, particles.size());

		efficiency =makeNeuralNetworkHistogram( numTrainedParticles,particles.size(), true);

		cout << "Error: " << error << endl; 
		cout << "Pion Efficiency: " << efficiency << endl; 

		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		//Combined Results
		cout << "Combined Results" << endl;
		error = fillNeuralNetworkPIDs(neuronLayers, 0, particles.size());

		efficiency = makeNeuralNetworkHistogram( 0,particles.size(), true);

		cout << "Error: " << error << endl; 
		cout << "Pion Efficiency: " << efficiency << endl; 

		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;

		return 0;
	}

	void fillInputs(ParticleInformation &particle, NeuronLayers& neuronLayers)
	{
		for(int j=0;j<9;j++)
		{
			float sum=0;
			for(int i=j*3;i<j*3+3;i++)
			{
				sum+=particle.getTimeBin()[i];
			}
		
			if(sum<1200)
			{
				sum=sum/(float)(1200);
			}
			else
			{
				sum=1;
			}
			neuronLayers.fillInputNeuron(j, sum);
		}
	}

	void fillTargets(ParticleInformation &particle, NeuronLayers& neuronLayers)
	{
		float target;
		if(particle.getType()==("ELECTRON"))
			target=(float) 1;
		else
			target=(float) 0;

		neuronLayers.setTarget(target, 0);
	
	}

	float fillNeuralNetworkPIDs(NeuronLayers& neuronLayers, int begin, int end)
	{
		float sumError=0;
		for(int u=begin;u<end;u++)
		{
			ParticleInformation particle = particles[u];
			
			fillInputs(particle, neuronLayers);
			fillTargets(particle, neuronLayers);
			neuronLayers.forwardPass();

		
			sumError +=neuronLayers.getErrorOutput(0);
	
			particles[u].setNeuralNetworkPID((int)(neuronLayers.getOutput(0)*255));
		}

		sumError = (float) sqrt(sumError/(float)(end-begin));
		return sumError;
	}

	float makeNeuralNetworkHistogram(int begin, int end, bool print)
	{
		int histogramE[256];
		std::fill(histogramE, histogramE+256,0);
		int histogramP[256];
		std::fill(histogramP, histogramP+256,0);

		int totalE=0;
		int totalP=0;

		for(int i=begin;i<end;i++)
		{
			ParticleInformation particle = particles[i];

			string type = particle.getType();
			if(type==("ELECTRON"))
			{
				histogramE[particle.getNeuralNetworkPID()]++;
				totalE++;

			}
			else if(type==("PION"))
			{
				histogramP[particle.getNeuralNetworkPID()]++;
				totalP++;
			}
		}

		if(print)
		{
			cout << "Electron Histogram" << endl;
			for(int i=0;i<256;i++)
			{
				cout << " " << histogramE[i];
			}
			cout<< endl;

			cout << "Pion Histogram" << endl;
			for(int i=0;i<256;i++)
			{
				cout << " " << histogramP[i];
			}
			cout<< endl;
		}


		int partNintyE=totalE*0.9;
		int indexOfNinty;
		int countingE=0;
		for(int i=255;i>=0;i--)
		{
			countingE+=histogramE[i];
			if(countingE>=partNintyE)
			{
				indexOfNinty=i;
				break;
			}
		}

		int pionsMisidentified=0;
		for(int i=indexOfNinty;i< 256;i++)
		{
			pionsMisidentified+=histogramP[i];
		}

		return (pionsMisidentified/(float)(totalP));
	}


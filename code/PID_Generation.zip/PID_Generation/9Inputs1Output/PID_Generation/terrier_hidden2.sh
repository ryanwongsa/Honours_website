#!/bin/bash

./pid_gen Simulation\ Data/NewDataLimited.txt 2 1 100000 > NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 2 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 3 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 4 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 5 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 6 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 7 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 8 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 9 100000 >> NineOneTWO.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 10 100000 >> NineOneTWO.txt

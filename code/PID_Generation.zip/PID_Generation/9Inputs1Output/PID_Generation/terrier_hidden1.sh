#!/bin/bash

./pid_gen Simulation\ Data/NewDataLimited.txt 1 1 100000 > NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 2 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 3 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 4 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 5 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 6 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 7 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 8 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 9 100000 >> NineOne.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 10 100000 >> NineOne.txt

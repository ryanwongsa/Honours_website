#!/bin/bash

./pid_gen Simulation\ Data/NewDataLimited.txt 2 1 200000 > 9Inputs1Output_v2_threshold.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 2 200000 >> 9Inputs1Output_v2_threshold.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 3 200000 >> 9Inputs1Output_v2_threshold.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 2 4 200000 >> 9Inputs1Output_v2_threshold.txt


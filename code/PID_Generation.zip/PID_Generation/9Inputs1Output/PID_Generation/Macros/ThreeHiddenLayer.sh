#!/bin/bash

./pid_gen ToUseData.txt 3 4 1 100000 > ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 4 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 4 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 6 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 6 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 6 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 8 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 8 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 8 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 10 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 10 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 10 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 12 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 12 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 12 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 14 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 14 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 14 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 16 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 16 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 16 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 18 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 18 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 18 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 20 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 20 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 20 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 22 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 22 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 22 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 24 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 24 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 24 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 26 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 26 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 26 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 28 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 28 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 28 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 30 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 30 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 30 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 32 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 32 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 32 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 34 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 34 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 34 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 36 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 36 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 36 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 38 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 38 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 38 1 100000 >> ThreeHiddenLayerData.txt

./pid_gen ToUseData.txt 3 40 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 40 1 100000 >> ThreeHiddenLayerData.txt
./pid_gen ToUseData.txt 3 40 1 100000 >> ThreeHiddenLayerData.txt

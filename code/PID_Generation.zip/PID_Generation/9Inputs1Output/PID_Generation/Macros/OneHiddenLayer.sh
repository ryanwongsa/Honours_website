#!/bin/bash

./pid_gen ToUseData.txt 1 4 1 100000 > OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 4 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 4 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 6 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 6 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 6 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 8 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 8 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 8 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 10 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 10 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 10 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 12 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 12 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 12 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 14 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 14 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 14 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 16 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 16 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 16 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 18 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 18 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 18 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 20 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 20 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 20 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 22 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 22 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 22 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 24 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 24 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 24 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 26 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 26 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 26 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 28 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 28 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 28 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 30 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 30 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 30 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 32 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 32 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 32 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 34 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 34 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 34 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 36 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 36 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 36 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 38 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 38 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 38 1 100000 >> OneHiddenLayerData.txt

./pid_gen ToUseData.txt 1 40 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 40 1 100000 >> OneHiddenLayerData.txt
./pid_gen ToUseData.txt 1 40 1 100000 >> OneHiddenLayerData.txt

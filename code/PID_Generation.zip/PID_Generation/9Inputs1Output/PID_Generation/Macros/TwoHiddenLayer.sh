#!/bin/bash

./pid_gen ToUseData.txt 2 4 1 100000 > TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 4 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 4 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 6 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 6 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 6 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 8 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 8 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 8 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 10 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 10 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 10 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 12 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 12 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 12 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 14 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 14 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 14 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 16 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 16 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 16 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 18 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 18 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 18 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 20 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 20 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 20 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 22 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 22 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 22 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 24 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 24 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 24 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 26 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 26 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 26 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 28 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 28 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 28 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 30 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 30 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 30 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 32 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 32 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 32 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 34 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 34 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 34 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 36 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 36 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 36 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 38 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 38 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 38 1 100000 >> TwoHiddenLayerData.txt

./pid_gen ToUseData.txt 2 40 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 40 1 100000 >> TwoHiddenLayerData.txt
./pid_gen ToUseData.txt 2 40 1 100000 >> TwoHiddenLayerData.txt

#!/bin/bash

./pid_gen Simulation\ Data/NewDataLimited.txt 1 5 100000 > terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 6 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 7 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 8 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 9 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 10 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 11 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 12 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 13 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 14 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 15 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 16 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 17 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 18 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 19 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 20 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 21 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 22 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 23 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 24 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 25 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 26 100000 >> terrier_NEW.txt

./pid_gen Simulation\ Data/NewDataLimited.txt 1 27 100000 >> terrier_NEW.txt



// The content of this class is in the header file because this class is templated.

#include "WeakClassifiers.h"

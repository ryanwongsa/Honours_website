# Honours-Project

This repository contains all the code and data used for the honours project:
##### A Comparative Analysis of Boosting and Artificial Neural Networks for Particle Identification at ALICE.

